<html>
<head>
	<title>The Yorkshire Classic</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
<style>
	body {
    font-size: 20px;
    background-image:  url("https://images.unsplash.com/photo-1545575439-3261931f52f1?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=871&q=80");
	color:aliceblue;
    background-repeat: no-repeat;
  background-attachment: fixed;
  /* background-position: center; */
  background-size: 100% 100%;
  
}
h1{
    font-size: 50px;
    color: white;
}
.btn {
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #696969;
    border: none;
    border-radius: 5px;
}
form{
	background: #4682B4;
	opacity: 1;
}
</style>
</head>
<body>

	<h1 style="text-align: center;">The Yorkshire Classic</h1>

	<form method="post" action="york_insert.php" >
		<div class="input-group">
			<label>Rider ID</label>
			<input type="text" name="RiderID" value="">
		</div>
		<div class="input-group">
			<label>Rider Name</label>
			<input type="text" name="RiderName" value="">
		</div>
		<div class="input-group">
			<label>Rider Club</label>
			<input type="text" name="RiderClub" value="">
		</div>
		<div class="input-group">
			<label>Start Time</label>
			<input type="text" name="StartTime" value="">
		</div>
        <div class="input-group">
			<label>End Time</label>
			<input type="text" name="EndTime" value="">
		</div>
        <div class="input-group">
			<label>Position</label>
			<input type="text" name="Position" value="">
		</div>
		<div class="input-group">
		<button class="btn" type="submit" name="save" >Add Record</button>
		
		</div>
	</form>


	<form method="post" action="york_delete.php" >
		<div class="input-group">
			<label>Rider ID</label>
			<input type="text" name="RiderID" value="">
		<div class="input-group">
			<a><button class="btn" type="submit" name="save" >Delete Record</button></a>
		</div>
		</div>
	</form>


	<form method="post" action="york_list.php" >
			<div class="input-group">
			<button class="btn" type="submit" name="Details" >Yorkshire Classic Results</button>
		</div>
	</form>


	<form method="GET" action="york_search.php" >
		<div class="input-group">
			<input type="text" name="search" required value =  "<?php if(isset($_GET['search'])){echo $_GET['search'];}?>" class="form-control" placeholder="Search Records">
			<button class="btn" type="submit" name="srch" >Search Record</button>
		</div>
	</form>


	<form method="post" action="york_update.php" >
			<div class="input-group">
			<button class="btn" type="submit" name="Details" >Edit Record</button>
		</div>
	</form>


</body>
</html>