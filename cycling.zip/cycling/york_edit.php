<?php
include_once("configg.php");
if(isset($_POST['update']))
{	

$RiderID = mysqli_real_escape_string($conn, $_POST['RiderID']);
$RiderName = mysqli_real_escape_string($conn, $_POST['RiderName']);
$RiderClub = mysqli_real_escape_string($conn, $_POST['RiderClub']);
$StartTime = mysqli_real_escape_string($conn, $_POST['StartTime']);
$EndTime = mysqli_real_escape_string($conn, $_POST['EndTime']);	
$Position = mysqli_real_escape_string($conn, $_POST['Position']);		
if(empty($RiderID) || empty($RiderName) || empty($RiderClub) || empty($StartTime) || empty($EndTime) || empty($Position)) {	
if(empty($RiderID)) {
echo '<font color="red">RiderID field is empty.</font><br>';
}
if(empty($RiderName)) {
echo '<font color="red">RiderName field is empty.</font><br>';
}
if(empty($RiderClub)) {
echo '<font color="red">RiderClub field is empty.</font><br>';
}
if(empty($StartTime)) {
    echo '<font color="red">StartTime field is empty.</font><br>';
}
if(empty($EndTime)) {
    echo '<font color="red">EndTime field is empty.</font><br>';
}
if(empty($Position)) {
    echo '<font color="red">Position field is empty.</font><br>';
}		
} else {	
$result = mysqli_query($conn, "UPDATE yorkshire SET RiderName='$RiderName',RiderClub='$RiderClub',StartTime='$StartTime', EndTime='$EndTime', Position='$Position'  WHERE RiderID=$RiderID");
header("Location: yorkshire.php");
}
}
?>