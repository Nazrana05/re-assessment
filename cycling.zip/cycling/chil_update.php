<?php
// including the database connection file
include_once("configg.php");

?>
<html>
<head>	
	<title>Edit Records</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <style>
        	body {
    font-size: 20px;
    background-image:  url("https://images.unsplash.com/photo-1452573992436-6d508f200b30?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=873&q=80");
	color:aliceblue;
    background-repeat: no-repeat;
  background-attachment: fixed;
  /* background-position: center; */
  background-size: 100% 100%;
  
}
h1{
    font-size: 50px;
    color: white;
}
.btn {
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #696969;
    border: none;
    border-radius: 5px;
}
form{
	background: #483D8B;
	opacity: 0.9;
}
    </style>
</head>

<body>
	<a href="chilterns.php">Home</a>
	<br><br>
	
	<form name="form1" method="post" action="chil_edit.php">
		<table border="0">
		<tr>
				<td>Rider ID</td>
				<td><input type="text" name="RiderID" value=""></td>
			</tr>
			<tr>
				<td>Rider Name</td>
				<td><input type="text" name="RiderName" value=""></td>
			</tr>
			<tr>
				<td>Rider Club</td>
				<td><input type="text" name="RiderClub" value=""></td>
			</tr>
		<tr> 
				<td>Start Time</td>
				<td><input type="text" name="StartTime" value=""></td>
			</tr>
            <tr> 
				<td>End Time</td>
				<td><input type="text" name="EndTime" value=""></td>
			</tr>
            <tr> 
				<td>Position</td>
				<td><input type="text" name="Position" value=""></td>
			</tr>
			<tr>
				
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>