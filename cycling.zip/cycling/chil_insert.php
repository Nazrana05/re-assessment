<!DOCTYPE html>
<html>

<head>
	<title>Insert Records</title>
</head>

<body>
	<center>
		<?php

		 	$db_username = 'root';
 			$db_password = '';
 			$db_name = 'cycling';
 			$db_host = 'localhost:3306';
		$conn = new mysqli($db_host, $db_username, $db_password,$db_name);
			if(!$conn) { 
    		echo "Unable to connect database".mysqli_error($conn);die; 
				} else { 
    				echo "Records Inserted"; 
						}
		
		// Taking all values from the form data(input)
		$RiderID = $_REQUEST['RiderID'];
		$RiderName = $_REQUEST['RiderName'];
		$RiderClub = $_REQUEST['RiderClub'];
		$StartTime = $_REQUEST['StartTime'];
        $EndTime = $_REQUEST['EndTime'];
        $Position = $_REQUEST['Position'];
		
		
		// Performing insert query execution
		$sql = "INSERT INTO chilterns VALUES ('$RiderID','$RiderName',
			'$RiderClub','$StartTime','$EndTime','$Position')";
		
		if(mysqli_query($conn, $sql)){
			echo "<h3>New Rider record has been stored"." Check Your Database</h3>";
								

			echo nl2br("\n$RiderID\n$RiderName\n $RiderClub\n $StartTime\n $EndTime\n  "
				. "$Position");
		} else{
			echo "ERROR: Hush! Sorry $sql. "
				. mysqli_error($conn);
		}
		
		
		// Close connection
		mysqli_close($conn);
		?>
	</center>
	
	
	
</body>

</html>