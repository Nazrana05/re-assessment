<?php
// including the database connection file
include_once("configg.php");

?>
<html>
<head>	
	<title>Edit Records</title>
    <link rel="stylesheet" type="text/css" href="style1.css">
    <style>
        	body {
    font-size: 20px;
    background-image:  url("https://images.unsplash.com/photo-1452573992436-6d508f200b30?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=873&q=80");
	color:aliceblue;
    background-repeat: no-repeat;
  background-attachment: fixed;
  /* background-position: center; */
  background-size: 100% 100%;
  
}
h1{
    font-size: 50px;
    color: white;
}
.btn {
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #696969;
    border: none;
    border-radius: 5px;
}
form{
	background: #483D8B;
	opacity: 0.9;
}
    </style>
</head>

<body>
	<a href="add_event.php">Home</a>
	<br><br>
	
	<form name="form1" method="post" action="event_edit.php">
		<table border="0">
		<tr>
				<td>Event ID</td>
				<td><input type="text" name="EventID" value=""></td>
			</tr>
			<tr>
				<td>Event Name</td>
				<td><input type="text" name="EventName" value=""></td>
			</tr>
			<tr>
				<td>Event Location</td>
				<td><input type="text" name="EventLocation" value=""></td>
			</tr>
		<tr> 
				<td>Event Date</td>
				<td><input type="text" name="EventDate" value=""></td>
			</tr>
			<tr>
				
				<td><input type="submit" name="update" value="Update"></td>
			</tr>
		</table>
	</form>
</body>
</html>