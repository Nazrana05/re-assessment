<html>
<head>
	<title>The Chilterns Classic</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
<style>
	body {
    font-size: 20px;
    background-image:  url("https://images.unsplash.com/photo-1510005294384-c03e247f0542?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=723&q=80");
	color:aliceblue;
    background-repeat: no-repeat;
  background-attachment: fixed;
  /* background-position: center; */
  background-size: 100% 100%;
  
}
h1{
    font-size: 50px;
    color: white;
}
.btn {
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #696969;
    border: none;
    border-radius: 5px;
}
form{
	background: #483D8B;
	opacity: 1;
}
</style>
</head>
<body>

	<h1 style="text-align: center;">EVENTS</h1>

	<form method="post" action="chil_insert.php" >
		<div class="input-group">
			<label>Event ID</label>
			<input type="text" name="EventID" value="">
		</div>
		<div class="input-group">
			<label>Event Name</label>
			<input type="text" name="EventName" value="">
		</div>
		<div class="input-group">
			<label>Event Location</label>
			<input type="text" name="EventLocation" value="">
		</div>
		<div class="input-group">
			<label>Event Date</label>
			<input type="text" name="EventDate" value="">
		</div>
		<div class="input-group">
		<button class="btn" type="submit" name="save" >Add Event</button>
		
		</div>
	</form>

    <form method="post" action="event_delete.php" >
		<div class="input-group">
			<label>Event ID</label>
			<input type="text" name="EventID" value="">
		<div class="input-group">
			<a><button class="btn" type="submit" name="save" >Delete Event</button></a>
		</div>
		</div>
	</form>

    <form method="post" action="event_list.php" >
			<div class="input-group">
			<button class="btn" type="submit" name="Details" >Event Results</button>
		</div>
	</form>


    <form method="GET" action="event_search.php" >
		<div class="input-group">
			<input type="text" name="search" required value =  "<?php if(isset($_GET['search'])){echo $_GET['search'];}?>" class="form-control" placeholder="Search Records">
			<button class="btn" type="submit" name="srch" >Search Event</button>
		</div>
	</form>

    <form method="post" action="event_update.php" >
			<div class="input-group">
			<button class="btn" type="submit" name="Details" >Edit Event</button>
		</div>
	</form>
</body>
</html>