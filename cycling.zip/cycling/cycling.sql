-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Aug 19, 2022 at 09:52 PM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `cycling`
--

-- --------------------------------------------------------

--
-- Table structure for table `chilterns`
--

CREATE TABLE `chilterns` (
  `RiderID` varchar(100) NOT NULL,
  `RiderName` varchar(100) NOT NULL,
  `RiderClub` varchar(100) NOT NULL,
  `StartTime` varchar(100) NOT NULL,
  `EndTime` varchar(100) NOT NULL,
  `Position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `chilterns`
--

INSERT INTO `chilterns` (`RiderID`, `RiderName`, `RiderClub`, `StartTime`, `EndTime`, `Position`) VALUES
('6207', 'Angus Abraham', 'Alton Cycling Club', '8:11:25', '11:15:30', '1'),
('6210', 'Jason Adams', 'Fenland Clarion Cycling Club', '8:12:34', '11:24:12', '2'),
('6211', 'Soyen Adams', 'Lee Valley Youth Cycling Club ', '8:12:50', '11:28:23', '3'),
('6249', 'Ben Adler', 'Redhill Cycling Club', '8:13:07', '11:31:56', '4'),
('6321', 'Andy Ainscough', 'Stockport Clarion Cycling Club', '8:12:39', '11:34:16', '5'),
('6459', 'Caroline Ali', 'Westerham Cycling Club', '8:13:39', '11:39:23', '6'),
('6488', 'David Allan', 'Otley Cycle Club', '8:12:47', '11:45:03', '7'),
('6526', 'Ian Amstad', 'Shaftesbury Cycling Club', '8:12:55', '11:52:36', '8'),
('6602', 'Gabriel Anguiano Rodriguwz', 'Mildenhall Cycling Club', '8:13:14', '12:03:12', '9'),
('6621', 'Gareth Bridge', 'London Cycling Club', '8:13:22', '12:07:28', '10');

-- --------------------------------------------------------

--
-- Table structure for table `mendips`
--

CREATE TABLE `mendips` (
  `RiderID` varchar(100) NOT NULL,
  `RiderName` varchar(100) NOT NULL,
  `RiderClub` varchar(100) NOT NULL,
  `StartTime` varchar(100) NOT NULL,
  `EndTime` varchar(100) NOT NULL,
  `Position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `mendips`
--

INSERT INTO `mendips` (`RiderID`, `RiderName`, `RiderClub`, `StartTime`, `EndTime`, `Position`) VALUES
('6795', 'Phil Addis', 'Hinckley Cycle Racing Club', '8:29:01', '12:15:34', '1'),
('6828', 'Clive Agent', 'Crabwood Cycling Club', '8:30:32', '12:21:57', '2'),
('6875', 'Mark Agent', 'Calder Clarion Cycling Club', '8:30:56', '12:24:17', '3'),
('6883', 'Geoff Albutt', 'Bedfordshire Road Cycling Club', '8:31:28', '12:29:20', '4'),
('6907', 'Hossam Ashraf', 'Aberdeen Wheelers Cycling Club', '8:30:18', '12:34:44', '5'),
('6936', 'Robert Back', 'Wolverhampton Wheelers Cycling Club', '8:31:27', '12:37:25', '6'),
('6963', 'John Baker', 'Verulam Cycling Club', '8:32:04', '12:40:00', '7'),
('6982', 'Martin Baker', 'Team Spirit Cycling Club', '8:31:35', '12:43:30', '8'),
('6998', 'Simon Ball', 'South Western Road Club', '8:31:14', '12:47:52', '9'),
('7004', 'Steven Barton', 'Reading Velodrome Racing Club', '8:32:24', '12:50:23', '10');

-- --------------------------------------------------------

--
-- Table structure for table `upcoming`
--

CREATE TABLE `upcoming` (
  `EventID` varchar(100) NOT NULL,
  `EventName` varchar(100) NOT NULL,
  `EventLocation` varchar(100) NOT NULL,
  `EventDate` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `upcoming`
--

INSERT INTO `upcoming` (`EventID`, `EventName`, `EventLocation`, `EventDate`) VALUES
('1001', 'The Surrey Hills Classic', 'Cranleigh, Surrey', '7th October, 2022'),
('1002', 'The Jurassic Classic', 'Bovington, Dorset', '21st October, 2022'),
('1003', 'The New Forest Classic', 'Southampton, Hampshire', '9th November, 2022'),
('1004', 'The Cambridgeshire Classic', 'Huntingdon, Cambridgeshire ', '26th November, 2022'),
('1005', 'The Wiltshire Classic', 'Salisbury, Wiltshire', '12th December, 2022'),
('1006', 'The Gravel Series South Downs', 'Amberley, West Sussex', '28th December, 2022');

-- --------------------------------------------------------

--
-- Table structure for table `yorkshire`
--

CREATE TABLE `yorkshire` (
  `RiderID` varchar(100) NOT NULL,
  `RiderName` varchar(100) NOT NULL,
  `RiderClub` varchar(100) NOT NULL,
  `StartTime` varchar(100) NOT NULL,
  `EndTime` varchar(100) NOT NULL,
  `Position` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `yorkshire`
--

INSERT INTO `yorkshire` (`RiderID`, `RiderName`, `RiderClub`, `StartTime`, `EndTime`, `Position`) VALUES
('6374', 'Jonny Adamson', 'Oxonian Cycling Club ', '8:06:26', '11.25:19', '1'),
('6388', 'William Hadlee', 'Monk Fryston Cycling Club', '8:06:44', '11.29:27', '2'),
('6404', 'Vincent Aitkins', 'Maldon & District Cc', '8:07:02', '11.34:16', '3'),
('6411', 'Richard Allen', 'Lunicus Cycling Club ', '8:07:32', '11.38:33', '4'),
('6432', 'Mark Aulsberry', 'Hinckley Cycle Racing Club ', '8:07:11', '11.43:17', '5'),
('6478', 'Michael Austin', 'Farnham Road Cycling Club', '8:07:31', '11.47:55', '6'),
('6485', 'Dennis Barnard', 'Erewash Valley Cycling Club', '8:07:42', '11.50:21', '7'),
('6493', 'Chris Barraclough', 'Dinnington Racing Club', '8:07:02', '11.53:01', '8'),
('6510', 'Jan Basha', 'Coventry Cycling Club', '8:08:03', '11.58:29', '9'),
('6523', 'Ian Bentley', 'Bath Cycling Club', '8:07:36', '12.08:13', '10');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `chilterns`
--
ALTER TABLE `chilterns`
  ADD PRIMARY KEY (`RiderID`);

--
-- Indexes for table `mendips`
--
ALTER TABLE `mendips`
  ADD PRIMARY KEY (`RiderID`);

--
-- Indexes for table `upcoming`
--
ALTER TABLE `upcoming`
  ADD PRIMARY KEY (`EventID`);

--
-- Indexes for table `yorkshire`
--
ALTER TABLE `yorkshire`
  ADD PRIMARY KEY (`RiderID`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
