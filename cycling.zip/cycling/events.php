<html>
<head>
	<title>Cycling League Events</title>
	<link rel="stylesheet" type="text/css" href="style1.css">
<style>
	body {
    font-size: 20px;
    background-image:  url("https://images.unsplash.com/photo-1628440167042-197d8eb88929?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80");
	color:aliceblue;
    background-repeat: no-repeat;
  background-attachment: fixed;
  background-size: 100% 100%;

  
}
h1{
    font-size: 50px;
    color: white;
}
.btn {
    padding: 10px;
    font-size: 15px;
    color: white;
    background: #696969;
    border: none;
    border-radius: 5px;
}
form{
	background: #BC8F8F;
	opacity: 1;
}
</style>
</head>
<body>

	<h1 style="text-align: center;">Cycling League Events</h1>

	

	<form method="post" action="chilterns.php" >
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Chilterns Event</button>
		</div>
		</div>
	</form>


	<form method="post" action="mendips.php" >
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Mendips Event</button>
		</div>
		</div>
	</form>
	
	<form method="post" action="yorkshire.php" >
		<div class="input-group">
			<button class="btn" type="submit" name="save" >Yorkshire Event</button>
		</div>
		</div>
	</form>


</form>
</body>
</html>