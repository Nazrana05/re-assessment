<!DOCTYPE html>
<html lang="en">
<head>
    
    <title>Delete Record</title>
</head>
<body>

    <?php
			$db_username = 'root';
 			$db_password = '';
 			$db_name = 'cycling';
 			$db_host = 'localhost:3306';
			$conn = new mysqli($db_host, $db_username, $db_password,$db_name);
			if(!$conn) { 
    		echo "Unable to connect database".mysqli_error($conn);die; 
				} else { 
    				echo ""; 
						}

// sql to delete a record
// $ID = $_REQUEST['EmpName1'];

$sql = "DELETE FROM chilterns WHERE RiderID='" . $_REQUEST["RiderID"] . "'";

if ($conn->query($sql) === TRUE) {
  echo "Record deleted successfully";
} else {
  echo "Error deleting record: " . $conn->error;
}

$conn->close();
?>

</body>
</html>

