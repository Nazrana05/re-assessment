<?php

// Username is root
            $db_username = 'root';
 			$db_password = '';
 			$db_name = 'cycling';
 			$db_host = 'localhost:3306';
		    $conn = new mysqli($db_host, $db_username, $db_password,$db_name);

// Checking for connections
if ($conn->connect_error) {
	die('Connection Error (' .
	$conn->connect_errno . ') '.
	$conn->connect_error);
}

// SQL query to select data from database
//$sql = "SELECT * FROM employee WHERE EmpNo = $EmpNo2 ";
//$result = $conn->query($sql);
//$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Search Records</title>
	<!-- CSS FOR STYLING THE PAGE -->
	<style>
		table {
			margin: 0 auto;
			font-size: large;
			border: 1px solid black;
		}

		h1 {
			text-align: center;
			color:    #1E90FF;
			font-size: 50px;
			font-family: 'Gill Sans';
		}

		td {
			background-color: #F5DEB3;
			border: 1px solid black;
		}

		th,
		td {
			font-weight: bold;
			border: 1px solid black;
			padding: 10px;
			text-align: center;
		}

		td {
			font-weight: lighter;
		}
		body {
    			font-size: 19px;
    			background-image:  url("https://images.unsplash.com/photo-1558009525-8518ac46127d?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80");
                background-repeat: no-repeat;
                background-attachment: fixed;
                background-size: 100% 100%;
    	}
    	th {
			background-color: #778899;
			border: 1px solid black;
		}



	</style>
</head>

<body>
	<section>
		<h1>Here is Your Results</h1>
		
		<table>
            <thead>
			    <tr>
				<th>Rider ID</th>
				<th>Rider Name</th>
				<th>Rider Club</th>
                <th>Start Time</th>
                <th>End Time</th>
                <th>Position</th>
            </thead> 
            <tbody>
                <?php
                    $conn = new mysqli($db_host, $db_username, $db_password,$db_name);
                    if(isset($_GET['search']))
                    {
                        $filtervalues=$_GET['search'];
                        $query="SELECT *FROM chilterns WHERE CONCAT(RiderID,RiderName,RiderClub,StartTime,EndTime,Position) LIKE '%$filtervalues%'";
                        $query_run=mysqli_query ($conn, $query);

                        if(mysqli_num_rows($query_run)>0)
                        {
                            foreach($query_run as $items)
                            {
                                ?>
                                <tr>
                                    <td><?= $items['RiderID']; ?></td>
                                    <td><?= $items['RiderName']; ?></td>
                                    <td><?= $items['RiderClub']; ?></td>
                                    <td><?= $items['StartTime']; ?></td>
                                    <td><?= $items['EndTime']; ?></td>
                                    <td><?= $items['Position']; ?></td>
                                </tr>
                                <?php
                            }
                        }
                        else
                        {
                            ?>
                                <tr>
                                    <td colspan="4">No Record Found</td>
                                </tr>
                            <?php
                        }
                    }
                    ?>
            </tbody>
               
			</tr>
			<!-- PHP CODE TO FETCH DATA FROM ROWS-->
			
		</table>
	</section>
</html>