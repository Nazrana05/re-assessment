<?php

// Username is root
            $db_username = 'root';
 			$db_password = '';
 			$db_name = 'cycling';
 			$db_host = 'localhost:3306';
		    $conn = new mysqli($db_host, $db_username, $db_password,$db_name);

// Checking for connections
if ($conn->connect_error) {
	die('Connection Error (' .
	$conn->connect_errno . ') '.
	$conn->connect_error);
}

// SQL query to select data from database
$sql = "SELECT * FROM Upcoming ORDER BY EventID ASC ";
$result = $conn->query($sql);
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">

<head>
	<meta charset="UTF-8">
	<title>Event Results</title>
	<!-- CSS FOR STYLING THE PAGE -->
	<style>
		table {
			margin: 0 auto;
			font-size: large;
			border: 1px solid black;
		}

		h1 {
			text-align: center;
			color: #1E90FF;
			font-size: 50px;
			font-family: 'Gill Sans';
		}

		td {
			background-color: #D8BFD8;
			border: 1px solid black;
		}

		th,
		td {
			font-weight: bold;
			border: 1px solid black;
			padding: 10px;
			text-align: center;
		}

		td {
			font-weight: lighter;
		}
		body {
    			font-size: 19px;
    			background-image:  url("https://images.unsplash.com/photo-1515164084382-4ac60f929e06?ixlib=rb-1.2.1&ixid=MnwxMjA3fDB8MHxwaG90by1wYWdlfHx8fGVufDB8fHx8&auto=format&fit=crop&w=870&q=80");
				background-size: 100% 100%;
				background-repeat: no-repeat;
  				background-attachment: fixed;
    	}
    	th {
			background-color: #778899;
			border: 1px solid black;
		}


}
	</style>
</head>

<body>
	<section>
		<h1>Event Results</h1>
		
		<table>
			<tr>
				<th>Event ID</th>
				<th>Event Name</th>
				<th>Event Location</th>
                <th>Event Date</th>
                
			</tr>
			<!-- PHP CODE TO FETCH DATA FROM ROWS-->
			<?php // LOOP TILL END OF DATA
				while($rows=$result->fetch_assoc())
				{
			?>
			<tr>
				<!--FETCHING DATA FROM EACH
					ROW OF EVERY COLUMN-->
				<td><?php echo $rows['EventID'];?></td>
				<td><?php echo $rows['EventName'];?></td>
				<td><?php echo $rows['EventLocation'];?></td>
                <td><?php echo $rows['EventDate'];?></td>
			</tr>
			<?php
				}
			?>
		</table>
	</section>

</html>
