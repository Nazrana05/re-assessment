<?php
include_once("configg.php");
if(isset($_POST['update']))
{	

$EventID = mysqli_real_escape_string($conn, $_POST['EventID']);
$EventName = mysqli_real_escape_string($conn, $_POST['EventName']);
$EventLocation = mysqli_real_escape_string($conn, $_POST['EventLocation']);
$EventDate = mysqli_real_escape_string($conn, $_POST['EventDate']);		
if(empty($EventID) || empty($EventName) || empty($EventLocation) || empty($EventDate)) {	
if(empty($EventID)) {
echo '<font color="red">EventID field is empty.</font><br>';
}
if(empty($EventName)) {
echo '<font color="red">EventName field is empty.</font><br>';
}
if(empty($EventLocation)) {
echo '<font color="red">EventLocation field is empty.</font><br>';
}
if(empty($EventDate)) {
    echo '<font color="red">EventDate field is empty.</font><br>';
}		
} else {	
$result = mysqli_query($conn, "UPDATE Upcoming SET EventName='$EventName',EventLocation='$EventLocation',EventDate='$EventDate' WHERE EventID=$EventID");
header("Location: add_event.php");
}
}
?>