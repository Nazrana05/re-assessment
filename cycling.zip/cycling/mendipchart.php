<?php

$link=mysqli_connect("localhost","root","");
mysqli_select_db($link,"cycling");

$test=array();

$count=0;

$res=mysqli_query($link,"SELECT RiderID,StartTime FROM `mendips` ORDER BY Position"
);
while($row=mysqli_fetch_array($res))
{

	$test[$count]["label"]=$row["RiderID"];
	$test[$count]["y"]=$row["StartTime"];
	$count=$count+1;
}

$test1=array();

$count1=0;

$res1=mysqli_query($link,"SELECT RiderID,EndTime FROM `mendips` ORDER BY Position"
);
while($row1=mysqli_fetch_array($res1))
{

	$test1[$count1]["label"]=$row1["RiderID"];
	$test1[$count1]["y"]=$row1["EndTime"];
	$count1=$count1+1;
}
	
?>
<!DOCTYPE HTML>
<html>
<head>  
<script>
window.onload = function () {
 
var chart = new CanvasJS.Chart("chartContainer", {
	animationEnabled: true,
	theme: "light2",
	title:{
		text: "Cyclist Starting time and Ending time"
	},
	axisX: {
		title: "Rider ID"
	},
	axisY:{
		includeZero: true
	},
	legend:{
		cursor: "pointer",
		verticalAlign: "center",
		horizontalAlign: "right",
		itemclick: toggleDataSeries
	},
	data: [{
		type: "column",
		name: "Start Time",
		indexLabel: "{y}",
		yValueFormatString: "#0.##",
		showInLegend: true,
		dataPoints: <?php echo json_encode($test, JSON_NUMERIC_CHECK); ?>
	},{
		type: "column",
		name: "End Time",
		indexLabel: "{y}",
		yValueFormatString: "#0.##",
		showInLegend: true,
		dataPoints: <?php echo json_encode($test1, JSON_NUMERIC_CHECK); ?>
	}]
});
chart.render();
 
function toggleDataSeries(e){
	if (typeof(e.dataSeries.visible) === "undefined" || e.dataSeries.visible) {
		e.dataSeries.visible = false;
	}
	else{
		e.dataSeries.visible = true;
	}
	chart.render();
}
 
}
</script>
</head>
<body>
<div id="chartContainer" style="height: 370px; width: 100%;"></div>
<script src="https://canvasjs.com/assets/script/canvasjs.min.js"></script>
</body>
</html>      